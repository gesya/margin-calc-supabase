
'use client';
import { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  'https://jipqfwgiibspfelvujvb.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImppcHFmd2dpaWJzcGZlbHZ1anZiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQ2NDI3MzgsImV4cCI6MjA3MDIxODczOH0.U0bbjEvglNxW0KgAFAlkmbTGxF4hR6rZncNCLOVgW4Y'
);

export default function MarginCalculator() {
  const [form, setForm] = useState({
    product_name: '',
    product_url: '',
    batch_size: 1,
    purchase_price_yuan: 0,
    exchange_rate: 1700,
    sale_price: 0,
    transport_per_batch: 0,
    uzum_commission_percent: 15,
    logistics_cost_per_unit: 0,
    other_costs: 0
  });
  const [result, setResult] = useState(null);
  const [history, setHistory] = useState([]);

  useEffect(() => {
    fetchHistory();
  }, []);

  const fetchHistory = async () => {
    const { data } = await supabase
      .from('margin_calculations')
      .select('*')
      .order('created_at', { ascending: false });
    setHistory(data || []);
  };

  const calculate = () => {
    const rate = parseFloat(form.exchange_rate);
    const unit_purchase = form.purchase_price_yuan * rate;
    const transport_unit = form.transport_per_batch / form.batch_size;
    const commission = (form.sale_price * form.uzum_commission_percent) / 100;
    const tax = (form.sale_price * 0.03);
    const total_cost =
      unit_purchase + transport_unit + commission + tax +
      parseFloat(form.logistics_cost_per_unit) +
      parseFloat(form.other_costs);
    const profit_per_unit = form.sale_price - total_cost;
    const total_profit = profit_per_unit * form.batch_size;
    const margin_percent = ((profit_per_unit / form.sale_price) * 100) || 0;

    setResult({ profit_per_unit, total_profit, margin_percent, total_cost });
    return { profit_per_unit, total_profit, margin_percent, total_cost };
  };

  const save = async () => {
    const calc = calculate();
    await supabase.from('margin_calculations').insert({
      ...form,
      ...calc,
      recommendation: calc.margin_percent < 10 ? 'Низкая маржинальность' : 'OK'
    });
    fetchHistory();
  };

  return (
    <div className="max-w-4xl mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Калькулятор маржинальности</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <input placeholder="Название товара" className="input" value={form.product_name} onChange={e => setForm({ ...form, product_name: e.target.value })} />
          <input placeholder="Ссылка на товар" className="input" value={form.product_url} onChange={e => setForm({ ...form, product_url: e.target.value })} />
          <input type="number" placeholder="Количество в партии" className="input" value={form.batch_size} onChange={e => setForm({ ...form, batch_size: +e.target.value })} />
          <input type="number" placeholder="Закупка (¥)" className="input" value={form.purchase_price_yuan} onChange={e => setForm({ ...form, purchase_price_yuan: +e.target.value })} />
          <input type="number" placeholder="Курс ¥→сум" className="input" value={form.exchange_rate} onChange={e => setForm({ ...form, exchange_rate: +e.target.value })} />
          <input type="number" placeholder="Продажа (сум)" className="input" value={form.sale_price} onChange={e => setForm({ ...form, sale_price: +e.target.value })} />
          <input type="number" placeholder="Транспорт за партию" className="input" value={form.transport_per_batch} onChange={e => setForm({ ...form, transport_per_batch: +e.target.value })} />
          <input type="number" placeholder="Комиссия Uzum %" className="input" value={form.uzum_commission_percent} onChange={e => setForm({ ...form, uzum_commission_percent: +e.target.value })} />
          <input type="number" placeholder="Логистика на единицу" className="input" value={form.logistics_cost_per_unit} onChange={e => setForm({ ...form, logistics_cost_per_unit: +e.target.value })} />
          <input type="number" placeholder="Прочие расходы" className="input" value={form.other_costs} onChange={e => setForm({ ...form, other_costs: +e.target.value })} />
          <button className="btn" onClick={save}>Сохранить</button>
        </div>
        <div>
          {result && (
            <div className="space-y-2">
              <p>Прибыль с единицы: {result.profit_per_unit.toFixed(2)} сум</p>
              <p>Общая прибыль: {result.total_profit.toFixed(2)} сум</p>
              <p>Маржинальность: {result.margin_percent.toFixed(2)}%</p>
              <p>Общие затраты на ед.: {result.total_cost.toFixed(2)} сум</p>
            </div>
          )}
        </div>
      </div>

      <h2 className="text-xl font-semibold mt-8">История расчётов</h2>
      <ul className="mt-2 space-y-1">
        {history.map(h => (
          <li key={h.id} className="border p-2 rounded">
            <div>{h.product_name}</div>
            <div>Маржа: {h.margin_percent?.toFixed(2)}% | Прибыль/шт: {h.profit_per_unit?.toFixed(0)} сум</div>
            <div className="text-sm text-gray-400">{new Date(h.created_at).toLocaleString()}</div>
          </li>
        ))}
      </ul>
    </div>
  );
}
